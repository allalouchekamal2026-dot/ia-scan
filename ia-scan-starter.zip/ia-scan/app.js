const translations = {
fr: {
tagline:"Détectez les textes générés par l’IA",home:"Accueil",history:"Historique de session",about:"À propos",freeTitle:"Version gratuite",freeText:"Essayez l’interface sans créer de compte.",freeFoot:"Prototype — aucun score réel sans moteur connecté.",eyebrow:"DÉTECTION MULTILINGUE",headline:"Analysez votre texte et estimez s’il a été généré par l’IA",subhead:"Collez un texte pour préparer son analyse. IA Scan prend en charge le français, l’arabe et l’anglais.",textLabel:"Texte à analyser",langHint:"Choisissez la langue principale du texte ci-dessus.",upload:"Importer .txt",placeholder:"Collez ici votre texte…",clear:"Effacer",analyze:"Préparer l’analyse",notice:"Les détecteurs donnent des estimations, pas des preuves définitives. Cette version de démonstration n’est pas encore reliée à un moteur de détection.",feature1Title:"Détection IA",feature1Text:"Préparez une analyse de texte avec un moteur spécialisé.",feature2Title:"Analyse claire",feature2Text:"Des résultats expliqués et présentés avec prudence.",feature3Title:"3 langues",feature3Text:"Français, arabe et anglais, avec interface RTL.",feature4Title:"Confidentialité",feature4Text:"Le texte reste dans votre navigateur dans cette maquette.",historyHeading:"Historique de session",historyDesc:"Les textes ne sont pas envoyés à un serveur dans cette maquette.",emptyHistory:"Aucune analyse préparée pour le moment.",aboutHeading:"Un outil d’aide, pas un verdict",aboutDesc:"IA Scan vise à aider les utilisateurs à examiner l’origine probable d’un texte, sans prétendre déterminer son auteur avec certitude.",aboutWhat:"Ce que fait le prototype",about1:"Interface trilingue et adaptée à l’arabe.",about2:"Compteur de mots et importation de fichiers TXT.",about3:"Préparation d’une demande d’analyse, sans faux score.",aboutNext:"Étape suivante",aboutNextText:"Connecter un fournisseur de détection via un serveur sécurisé. Ne placez jamais une clé API secrète dans le code du navigateur.",footer:"Détectez. Vérifiez. Restez informé.",empty:"Veuillez saisir un texte avant de continuer.",demoTitle:"Démo — aucun score réel",demoText:"Votre texte est prêt pour une future analyse, mais le moteur IA n’est pas connecté. Aucun pourcentage n’a été inventé.",word:"mots",char:"caractères",historyItem:"Analyse préparée",fileError:"Impossible de lire ce fichier. Essayez un fichier TXT.",tooLong:"Le fichier est trop volumineux pour cette maquette."
},
en: {
tagline:"Detect AI-generated text",home:"Home",history:"Session history",about:"About",freeTitle:"Free version",freeText:"Try the interface without creating an account.",freeFoot:"Prototype — no real score until a detector is connected.",eyebrow:"MULTILINGUAL DETECTION",headline:"Analyze your text and estimate whether it was AI-generated",subhead:"Paste text to prepare an analysis. IA Scan supports French, Arabic and English.",textLabel:"Text to analyze",langHint:"Choose the main language of your text above.",upload:"Import .txt",placeholder:"Paste your text here…",clear:"Clear",analyze:"Prepare analysis",notice:"Detectors provide estimates, not definitive proof. This demo is not yet connected to a detection engine.",feature1Title:"AI detection",feature1Text:"Prepare text analysis with a specialized engine.",feature2Title:"Clear analysis",feature2Text:"Results explained and presented cautiously.",feature3Title:"3 languages",feature3Text:"French, Arabic and English, with RTL interface support.",feature4Title:"Privacy",feature4Text:"In this mockup, text stays in your browser.",historyHeading:"Session history",historyDesc:"Text is not sent to a server in this mockup.",emptyHistory:"No prepared analyses yet.",aboutHeading:"An aid, not a verdict",aboutDesc:"IA Scan aims to help users examine the likely origin of text without claiming to determine authorship with certainty.",aboutWhat:"What this prototype does",about1:"Trilingual interface with Arabic support.",about2:"Word counter and TXT file import.",about3:"Prepares an analysis request without inventing a score.",aboutNext:"Next step",aboutNextText:"Connect a detection provider through a secure server. Never place a secret API key in browser code.",footer:"Detect. Verify. Stay informed.",empty:"Please enter text before continuing.",demoTitle:"Demo — no real score",demoText:"Your text is ready for a future analysis, but the AI engine is not connected. No percentage has been invented.",word:"words",char:"characters",historyItem:"Analysis prepared",fileError:"Could not read this file. Try a TXT file.",tooLong:"This file is too large for this mockup."
},
ar: {
tagline:"اكتشف النصوص المُنشأة بالذكاء الاصطناعي",home:"الرئيسية",history:"سجل الجلسة",about:"حول التطبيق",freeTitle:"نسخة مجانية",freeText:"جرّب الواجهة دون إنشاء حساب.",freeFoot:"نموذج أولي — لا توجد نتيجة حقيقية قبل ربط محرك الكشف.",eyebrow:"كشف متعدد اللغات",headline:"حلّل نصك وقدّر ما إذا كان قد أُنشئ بالذكاء الاصطناعي",subhead:"ألصق النص للتحضير لتحليله. يدعم IA Scan الفرنسية والعربية والإنجليزية.",textLabel:"النص المراد تحليله",langHint:"اختر اللغة الأساسية للنص.",upload:"استيراد TXT",placeholder:"ألصق النص هنا…",clear:"مسح",analyze:"تحضير التحليل",notice:"تقدم أدوات الكشف تقديرات وليست أدلة نهائية. هذا الإصدار التجريبي غير مرتبط بعد بمحرك كشف.",feature1Title:"كشف الذكاء الاصطناعي",feature1Text:"تحضير تحليل النص باستخدام محرك متخصص.",feature2Title:"تحليل واضح",feature2Text:"عرض النتائج وتفسيرها بحذر.",feature3Title:"ثلاث لغات",feature3Text:"الفرنسية والعربية والإنجليزية مع دعم اتجاه RTL.",feature4Title:"الخصوصية",feature4Text:"يبقى النص في المتصفح ضمن هذا النموذج.",historyHeading:"سجل الجلسة",historyDesc:"لا تُرسل النصوص إلى خادم في هذا النموذج.",emptyHistory:"لا توجد تحليلات محضّرة حتى الآن.",aboutHeading:"أداة مساعدة وليست حكماً نهائياً",aboutDesc:"يهدف IA Scan إلى مساعدة المستخدم على تقدير المصدر المحتمل للنص دون الادعاء بمعرفة مؤلفه على وجه اليقين.",aboutWhat:"ماذا يقدم النموذج الأولي؟",about1:"واجهة بثلاث لغات ودعم العربية.",about2:"عداد الكلمات واستيراد ملفات TXT.",about3:"تحضير طلب تحليل دون اختلاق نتيجة.",aboutNext:"الخطوة التالية",aboutNextText:"ربط مزود كشف عبر خادم آمن. لا تضع مفتاح API سرياً داخل كود المتصفح.",footer:"اكتشف. تحقّق. ابقَ على اطلاع.",empty:"يرجى إدخال نص للمتابعة.",demoTitle:"نسخة تجريبية — لا توجد نتيجة حقيقية",demoText:"النص جاهز لتحليل مستقبلي، لكن محرك الذكاء الاصطناعي غير متصل. لم يتم اختلاق أي نسبة.",word:"كلمات",char:"حروف",historyItem:"تحليل مُحضّر",fileError:"تعذرت قراءة الملف. جرّب ملف TXT.",tooLong:"الملف كبير جداً بالنسبة إلى هذا النموذج."
}
};

const $ = (s) => document.querySelector(s);
let currentLang = "fr";
let historyItems = [];

function setLanguage(lang) {
  currentLang = lang;
  const t = translations[lang];
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (t[key]) el.textContent = t[key];
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    if (t[key]) el.placeholder = t[key];
  });
  updateCount();
  renderHistory();
}
function countWords(text) {
  const trimmed = text.trim();
  return trimmed ? trimmed.split(/\s+/u).length : 0;
}
function updateCount() {
  const text = $("#textInput").value;
  const t = translations[currentLang];
  $("#wordCount").textContent = `${countWords(text)} ${t.word} · ${text.length} ${t.char}`;
}
function showView(view) {
  document.querySelectorAll(".view").forEach(el => el.hidden = true);
  $(`#${view}View`).hidden = false;
  document.querySelectorAll(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.view === view));
}
function renderHistory() {
  const container = $("#historyList");
  const t = translations[currentLang];
  if (!historyItems.length) {
    container.innerHTML = "";
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t.emptyHistory;
    container.appendChild(p);
    return;
  }
  container.innerHTML = "";
  historyItems.forEach(item => {
    const entry = document.createElement("div");
    entry.className = "history-entry";
    const strong = document.createElement("strong");
    strong.textContent = item.excerpt;
    const p = document.createElement("p");
    p.textContent = `${item.words} ${t.word} · ${item.time}`;
    entry.append(strong, p);
    container.appendChild(entry);
  });
}
$("#language").addEventListener("change", e => setLanguage(e.target.value));
$("#textInput").addEventListener("input", () => {
  updateCount();
  $("#resultPanel").hidden = true;
});
$("#clearButton").addEventListener("click", () => {
  $("#textInput").value = "";
  $("#resultPanel").hidden = true;
  updateCount();
  $("#textInput").focus();
});
$("#analyzeButton").addEventListener("click", () => {
  const text = $("#textInput").value.trim();
  const t = translations[currentLang];
  const panel = $("#resultPanel");
  if (!text) {
    panel.innerHTML = "";
    const strong = document.createElement("strong");
    strong.textContent = t.empty;
    panel.appendChild(strong);
    panel.hidden = false;
    return;
  }
  const item = { excerpt: text.length > 95 ? `${text.slice(0,95)}…` : text, words: countWords(text), time: new Date().toLocaleTimeString() };
  historyItems.unshift(item);
  historyItems = historyItems.slice(0, 10);
  panel.innerHTML = "";
  const strong = document.createElement("strong");
  strong.textContent = t.demoTitle;
  const p = document.createElement("p");
  p.textContent = t.demoText;
  panel.append(strong, p);
  panel.hidden = false;
});
$("#fileInput").addEventListener("change", async e => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const t = translations[currentLang];
  const panel = $("#resultPanel");
  if (file.size > 2 * 1024 * 1024) {
    panel.innerHTML = "";
    const p = document.createElement("p"); p.textContent = t.tooLong; panel.appendChild(p); panel.hidden = false; return;
  }
  try {
    if (!file.name.toLowerCase().endsWith(".txt")) throw new Error("txt only");
    $("#textInput").value = await file.text();
    updateCount();
    panel.hidden = true;
  } catch {
    panel.innerHTML = "";
    const p = document.createElement("p"); p.textContent = t.fileError; panel.appendChild(p); panel.hidden = false;
  }
  e.target.value = "";
});
document.querySelectorAll(".nav-item").forEach(button => button.addEventListener("click", () => {
  showView(button.dataset.view);
  if (button.dataset.view === "history") renderHistory();
}));
$("#themeToggle").addEventListener("click", () => document.body.classList.toggle("dark"));
setLanguage("fr");
updateCount();
