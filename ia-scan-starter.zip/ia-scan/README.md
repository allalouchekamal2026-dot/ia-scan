# IA Scan — prototype gratuit

Prototype statique trilingue (français, arabe, anglais) pour l'interface d'un détecteur de textes générés par IA.

## Ce qui fonctionne
- Interface responsive
- Changement de langue et mise en page RTL pour l'arabe
- Compteur de mots et caractères
- Import de fichiers TXT (limite 2 Mo)
- Historique temporaire en mémoire de session
- Mode clair/sombre
- Message explicite : aucune détection réelle n'est exécutée

## Ce qui n'est pas encore connecté
Ce prototype n'appelle aucune API et ne produit aucun score de détection. Pour ajouter une vraie détection, créer un backend sécurisé qui appelle le fournisseur choisi. Ne jamais mettre une clé secrète dans `app.js`, `index.html` ou tout autre fichier envoyé au navigateur.

## Tester localement
Ouvrir `index.html` dans un navigateur récent.

## Publier avec GitHub + Vercel
1. Créer un dépôt GitHub nommé `ia-scan`.
2. Ajouter `index.html`, `styles.css`, `app.js` et `README.md` à la racine du dépôt.
3. Sur Vercel, choisir **Add New → Project**, importer le dépôt `ia-scan`.
4. Pour ce site statique, laisser le framework sur **Other** et ne pas définir de commande de build. Déployer.
5. Vercel fournira une URL publique.

## Avant de lancer la détection réelle
- Vérifier les langues prises en charge et les limites du fournisseur.
- Tester les résultats avec des corpus humains et générés par IA dans les trois langues.
- Garder la clé API côté serveur dans une variable d'environnement.
- Définir une politique de confidentialité et de suppression.
- Afficher les scores comme des estimations, jamais comme des preuves définitives.
